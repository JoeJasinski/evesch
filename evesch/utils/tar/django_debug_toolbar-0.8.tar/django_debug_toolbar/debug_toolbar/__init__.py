VERSION = (0, 8, 1, 'alpha')
__version__ = '.'.join(map(str, VERSION))
