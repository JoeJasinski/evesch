
TITLE: ABOUT
	jQuery.ptTimeSelect is a jQuery plugin (<http://www.jquery.com>) that displays
	a popup allowing a user to define a time, which is written back
	to an input field.
	
	Documentation:
		Documentation can be found in the <doc> directory of the archive file
		downloaded. It is in html format.
		
	Examples:
		Examples can be found in the <example> directory of the archive file
		downloaded. They are in html format.  Start with the index.html file
	
	Deploying:
		The only files required to be included in your page/project are the
		src/jquery.ptTimeSelect.js and src/jquery.ptTimeSelect.css. It should
		be included after the jquery library and dimmentions plugin.
	
	
	----------------------
	Last updated:
	
	|	    $Date: 2007/05/17 17:00:38 $
	|	  $Author: paulinho4u $
	|	$Revision: 1.2 $

