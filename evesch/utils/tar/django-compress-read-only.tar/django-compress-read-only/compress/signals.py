from django.dispatch import Signal

css_filtered = Signal()
js_filtered = Signal()
